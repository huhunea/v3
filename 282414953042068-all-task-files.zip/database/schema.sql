-- Database Schema cho Website Share Tài Liệu
-- Tạo bởi: MiniMax Agent
-- Ngày: 2025-06-21

-- Tạo database
CREATE DATABASE IF NOT EXISTS khoahoc_share DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE khoahoc_share;

-- Bảng users (người dùng)
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    avatar_icon VARCHAR(50) DEFAULT 'user',
    display_name VARCHAR(100) NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    admin_badge VARCHAR(20) DEFAULT NULL, -- 'admin', 'moderator', 'vip', etc.
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    profile_bio TEXT DEFAULT NULL
);

-- Bảng sessions (phiên đăng nhập)
CREATE TABLE sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45),
    user_agent TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Bảng document_sections (các phần tài liệu để bình luận)
CREATE TABLE document_sections (
    id INT PRIMARY KEY AUTO_INCREMENT,
    section_type ENUM('tonghop', 'khoahoc') NOT NULL,
    section_category VARCHAR(50) NOT NULL, -- 'thpt', 'ngoaingu' cho tonghop; class cho khoahoc
    section_subject VARCHAR(50) DEFAULT NULL, -- môn học cho khoahoc
    title VARCHAR(200) NOT NULL,
    description TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Bảng comments (bình luận)
CREATE TABLE comments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    section_id INT NOT NULL,
    parent_comment_id INT DEFAULT NULL, -- NULL cho comment gốc, có giá trị cho reply
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_edited BOOLEAN DEFAULT FALSE,
    is_deleted BOOLEAN DEFAULT FALSE,
    deleted_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (section_id) REFERENCES document_sections(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_comment_id) REFERENCES comments(id) ON DELETE CASCADE
);

-- Bảng comment_reactions (cảm xúc cho bình luận)
CREATE TABLE comment_reactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    comment_id INT NOT NULL,
    reaction_type VARCHAR(20) NOT NULL, -- 'like', 'love', 'haha', 'wow', 'sad', 'angry'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_comment_reaction (user_id, comment_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (comment_id) REFERENCES comments(id) ON DELETE CASCADE
);

-- Bảng section_reactions (cảm xúc cho phần tài liệu)
CREATE TABLE section_reactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    section_id INT NOT NULL,
    reaction_type VARCHAR(20) NOT NULL, -- 'like', 'love', 'haha', 'wow', 'sad', 'angry'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_section_reaction (user_id, section_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (section_id) REFERENCES document_sections(id) ON DELETE CASCADE
);

-- Bảng admin_actions (hành động của admin)
CREATE TABLE admin_actions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    admin_user_id INT NOT NULL,
    action_type ENUM('delete_comment', 'ban_user', 'unban_user', 'promote_user', 'demote_user') NOT NULL,
    target_user_id INT DEFAULT NULL,
    target_comment_id INT DEFAULT NULL,
    reason TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (target_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (target_comment_id) REFERENCES comments(id) ON DELETE SET NULL
);

-- Bảng avatar_icons (các icon avatar có sẵn)
CREATE TABLE avatar_icons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    icon_name VARCHAR(50) UNIQUE NOT NULL,
    icon_emoji VARCHAR(10) NOT NULL,
    category VARCHAR(30) DEFAULT 'general',
    is_active BOOLEAN DEFAULT TRUE
);

-- Chèn dữ liệu mẫu cho avatar icons
INSERT INTO avatar_icons (icon_name, icon_emoji, category) VALUES
('user', '👤', 'general'),
('student', '🎓', 'education'),
('teacher', '👨‍🏫', 'education'),
('book', '📚', 'education'),
('star', '⭐', 'general'),
('heart', '❤️', 'general'),
('smile', '😊', 'general'),
('cool', '😎', 'general'),
('thinking', '🤔', 'general'),
('rocket', '🚀', 'general'),
('trophy', '🏆', 'general'),
('fire', '🔥', 'general'),
('thumbsup', '👍', 'general'),
('brain', '🧠', 'education'),
('pencil', '✏️', 'education'),
('lightbulb', '💡', 'education'),
('cat', '🐱', 'animals'),
('dog', '🐶', 'animals'),
('panda', '🐼', 'animals'),
('unicorn', '🦄', 'animals');

-- Chèn dữ liệu mẫu cho document sections
INSERT INTO document_sections (section_type, section_category, section_subject, title, description) VALUES
('tonghop', 'thpt', NULL, 'Tài liệu THPT tổng hợp', 'Tài liệu tổng hợp cho học sinh THPT'),
('tonghop', 'ngoaingu', NULL, 'Tài liệu Ngoại ngữ', 'Tài liệu học ngoại ngữ các loại'),
('khoahoc', '12', 'toan', 'Khóa học Toán lớp 12', 'Khóa học Toán học lớp 12 đầy đủ'),
('khoahoc', '12', 'ly', 'Khóa học Lý lớp 12', 'Khóa học Vật lý lớp 12 đầy đủ'),
('khoahoc', '12', 'hoa', 'Khóa học Hóa lớp 12', 'Khóa học Hóa học lớp 12 đầy đủ'),
('khoahoc', '12', 'sinh', 'Khóa học Sinh lớp 12', 'Khóa học Sinh học lớp 12 đầy đủ'),
('khoahoc', '12', 'su', 'Khóa học Sử lớp 12', 'Khóa học Lịch sử lớp 12 đầy đủ'),
('khoahoc', '12', 'dia', 'Khóa học Địa lớp 12', 'Khóa học Địa lý lớp 12 đầy đủ'),
('khoahoc', '12', 'gdcd', 'Khóa học GDCD lớp 12', 'Khóa học GDCD lớp 12 đầy đủ'),
('khoahoc', '12', 'anh', 'Khóa học Tiếng Anh lớp 12', 'Khóa học Tiếng Anh lớp 12 đầy đủ'),
('khoahoc', '12', 'tin', 'Khóa học Tin học lớp 12', 'Khóa học Tin học lớp 12 đầy đủ'),
('khoahoc', '11', 'toan', 'Khóa học Toán lớp 11', 'Khóa học Toán học lớp 11 đầy đủ'),
('khoahoc', '11', 'ly', 'Khóa học Lý lớp 11', 'Khóa học Vật lý lớp 11 đầy đủ'),
('khoahoc', '11', 'hoa', 'Khóa học Hóa lớp 11', 'Khóa học Hóa học lớp 11 đầy đủ'),
('khoahoc', '11', 'sinh', 'Khóa học Sinh lớp 11', 'Khóa học Sinh học lớp 11 đầy đủ'),
('khoahoc', '11', 'su', 'Khóa học Sử lớp 11', 'Khóa học Lịch sử lớp 11 đầy đủ'),
('khoahoc', '11', 'dia', 'Khóa học Địa lớp 11', 'Khóa học Địa lý lớp 11 đầy đủ'),
('khoahoc', '11', 'gdcd', 'Khóa học GDCD lớp 11', 'Khóa học GDCD lớp 11 đầy đủ'),
('khoahoc', '11', 'anh', 'Khóa học Tiếng Anh lớp 11', 'Khóa học Tiếng Anh lớp 11 đầy đủ'),
('khoahoc', '11', 'tin', 'Khóa học Tin học lớp 11', 'Khóa học Tin học lớp 11 đầy đủ'),
('khoahoc', '10', 'toan', 'Khóa học Toán lớp 10', 'Khóa học Toán học lớp 10 đầy đủ'),
('khoahoc', '10', 'ly', 'Khóa học Lý lớp 10', 'Khóa học Vật lý lớp 10 đầy đủ'),
('khoahoc', '10', 'hoa', 'Khóa học Hóa lớp 10', 'Khóa học Hóa học lớp 10 đầy đủ'),
('khoahoc', '10', 'sinh', 'Khóa học Sinh lớp 10', 'Khóa học Sinh học lớp 10 đầy đủ'),
('khoahoc', '10', 'su', 'Khóa học Sử lớp 10', 'Khóa học Lịch sử lớp 10 đầy đủ'),
('khoahoc', '10', 'dia', 'Khóa học Địa lớp 10', 'Khóa học Địa lý lớp 10 đầy đủ'),
('khoahoc', '10', 'gdcd', 'Khóa học GDCD lớp 10', 'Khóa học GDCD lớp 10 đầy đủ'),
('khoahoc', '10', 'anh', 'Khóa học Tiếng Anh lớp 10', 'Khóa học Tiếng Anh lớp 10 đầy đủ'),
('khoahoc', '10', 'tin', 'Khóa học Tin học lớp 10', 'Khóa học Tin học lớp 10 đầy đủ');

-- Tạo user admin mặc định (password: admin123)
INSERT INTO users (username, email, password_hash, avatar_icon, display_name, is_admin, admin_badge) VALUES
('admin', 'admin@khoahocgiasiure.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'star', 'Administrator', TRUE, 'admin');

-- Tạo indexes để tối ưu performance
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_sessions_token ON sessions(session_token);
CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_comments_section_id ON comments(section_id);
CREATE INDEX idx_comments_user_id ON comments(user_id);
CREATE INDEX idx_comments_parent_id ON comments(parent_comment_id);
CREATE INDEX idx_comment_reactions_comment_id ON comment_reactions(comment_id);
CREATE INDEX idx_section_reactions_section_id ON section_reactions(section_id);
CREATE INDEX idx_document_sections_type_category ON document_sections(section_type, section_category);
CREATE INDEX idx_document_sections_subject ON document_sections(section_subject);
