<?php
/**
 * System Check cho InfinityFree
 * Test các yêu cầu hệ thống và cấu hình
 * Tạo bởi: MiniMax Agent
 */

// Security: Chỉ cho phép chạy khi có parameter đặc biệt
if (!isset($_GET['check']) || $_GET['check'] !== 'system') {
    die('Access denied. Use: ?check=system');
}

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Check - KHOAHOCGIASIURE</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 20px;
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #1976d2, #42a5f5);
            color: #fff;
            padding: 30px;
            text-align: center;
        }
        
        .content {
            padding: 30px;
        }
        
        .check-section {
            margin-bottom: 30px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .section-header {
            background: #f8f9fa;
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            font-weight: 600;
            color: #333;
        }
        
        .section-body {
            padding: 20px;
        }
        
        .check-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .check-item:last-child {
            border-bottom: none;
        }
        
        .check-label {
            font-weight: 500;
        }
        
        .check-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 600;
        }
        
        .status-pass {
            background: #e8f5e8;
            color: #2e7d32;
        }
        
        .status-fail {
            background: #ffebee;
            color: #d32f2f;
        }
        
        .status-warning {
            background: #fff3e0;
            color: #f57c00;
        }
        
        .status-info {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .summary {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-top: 30px;
            text-align: center;
        }
        
        .summary.success {
            background: #e8f5e8;
            border: 2px solid #4caf50;
        }
        
        .summary.warning {
            background: #fff3e0;
            border: 2px solid #ff9800;
        }
        
        .summary.error {
            background: #ffebee;
            border: 2px solid #f44336;
        }
        
        .code-block {
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 10px;
            font-family: monospace;
            font-size: 0.9em;
            overflow-x: auto;
            margin: 10px 0;
        }
        
        .warning-box {
            background: #fff3cd;
            border: 1px solid #ffc107;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            color: #856404;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #1976d2;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin: 10px 5px;
            font-weight: 600;
        }
        
        .btn:hover {
            background: #1565c0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔧 System Check</h1>
            <p>Kiểm tra yêu cầu hệ thống và cấu hình cho KHOAHOCGIASIURE</p>
            <small>Thời gian: <?= date('Y-m-d H:i:s') ?></small>
        </div>
        
        <div class="content">
            <?php
            $checks = [];
            $hasErrors = false;
            $hasWarnings = false;
            
            // PHP Version Check
            $phpVersion = PHP_VERSION;
            $minPhpVersion = '7.4.0';
            $phpOK = version_compare($phpVersion, $minPhpVersion) >= 0;
            $checks['php']['PHP Version'] = [
                'status' => $phpOK ? 'pass' : 'fail',
                'message' => "PHP {$phpVersion}" . ($phpOK ? '' : " (cần >= {$minPhpVersion})"),
                'critical' => !$phpOK
            ];
            if (!$phpOK) $hasErrors = true;
            
            // PHP Extensions
            $requiredExtensions = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'openssl'];
            foreach ($requiredExtensions as $ext) {
                $loaded = extension_loaded($ext);
                $checks['php']["Extension: {$ext}"] = [
                    'status' => $loaded ? 'pass' : 'fail',
                    'message' => $loaded ? 'Có sẵn' : 'Thiếu',
                    'critical' => !$loaded
                ];
                if (!$loaded) $hasErrors = true;
            }
            
            // Optional Extensions
            $optionalExtensions = ['gd', 'curl', 'zip'];
            foreach ($optionalExtensions as $ext) {
                $loaded = extension_loaded($ext);
                $checks['php']["Extension (optional): {$ext}"] = [
                    'status' => $loaded ? 'pass' : 'warning',
                    'message' => $loaded ? 'Có sẵn' : 'Không có (không bắt buộc)',
                    'critical' => false
                ];
                if (!$loaded) $hasWarnings = true;
            }
            
            // Database Connection Test
            try {
                if (file_exists('backend/config/database.php')) {
                    require_once 'backend/config/database.php';
                    $db = new Database();
                    $dbTest = $db->testConnection();
                    
                    $checks['database']['Kết nối Database'] = [
                        'status' => $dbTest['success'] ? 'pass' : 'fail',
                        'message' => $dbTest['message'],
                        'critical' => !$dbTest['success']
                    ];
                    
                    if ($dbTest['success']) {
                        $info = $db->getServerInfo();
                        $checks['database']['MySQL Version'] = [
                            'status' => 'info',
                            'message' => $info['version'],
                            'critical' => false
                        ];
                        $checks['database']['Character Set'] = [
                            'status' => 'info',
                            'message' => $info['charset'],
                            'critical' => false
                        ];
                    } else {
                        $hasErrors = true;
                    }
                } else {
                    $checks['database']['Config File'] = [
                        'status' => 'fail',
                        'message' => 'backend/config/database.php không tồn tại',
                        'critical' => true
                    ];
                    $hasErrors = true;
                }
            } catch (Exception $e) {
                $checks['database']['Database Error'] = [
                    'status' => 'fail',
                    'message' => $e->getMessage(),
                    'critical' => true
                ];
                $hasErrors = true;
            }
            
            // File Permissions
            $filesToCheck = [
                'backend/config/database.php' => 'readable',
                'backend/api/auth.php' => 'readable',
                'backend/api/comments.php' => 'readable',
                'frontend/js/auth.js' => 'readable',
                '.htaccess' => 'readable'
            ];
            
            foreach ($filesToCheck as $file => $permission) {
                $exists = file_exists($file);
                $readable = $exists && is_readable($file);
                
                if (!$exists) {
                    $checks['files'][$file] = [
                        'status' => 'fail',
                        'message' => 'File không tồn tại',
                        'critical' => true
                    ];
                    $hasErrors = true;
                } else if (!$readable) {
                    $checks['files'][$file] = [
                        'status' => 'warning',
                        'message' => 'Không thể đọc',
                        'critical' => false
                    ];
                    $hasWarnings = true;
                } else {
                    $checks['files'][$file] = [
                        'status' => 'pass',
                        'message' => 'OK',
                        'critical' => false
                    ];
                }
            }
            
            // Server Info
            $checks['server']['Web Server'] = [
                'status' => 'info',
                'message' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                'critical' => false
            ];
            
            $checks['server']['Document Root'] = [
                'status' => 'info',
                'message' => $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown',
                'critical' => false
            ];
            
            $checks['server']['Host'] = [
                'status' => 'info',
                'message' => $_SERVER['HTTP_HOST'] ?? 'Unknown',
                'critical' => false
            ];
            
            // URL Rewrite Test
            $rewriteTest = function_exists('apache_get_modules') && in_array('mod_rewrite', apache_get_modules());
            $checks['server']['URL Rewrite'] = [
                'status' => $rewriteTest ? 'pass' : 'warning',
                'message' => $rewriteTest ? 'mod_rewrite có sẵn' : 'Không thể kiểm tra (có thể OK)',
                'critical' => false
            ];
            
            // HTTPS Check
            $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;
            $checks['security']['HTTPS'] = [
                'status' => $isHttps ? 'pass' : 'warning',
                'message' => $isHttps ? 'Đang sử dụng HTTPS' : 'Không sử dụng HTTPS',
                'critical' => false
            ];
            if (!$isHttps) $hasWarnings = true;
            
            // PHP Settings
            $settings = [
                'memory_limit' => ini_get('memory_limit'),
                'max_execution_time' => ini_get('max_execution_time'),
                'upload_max_filesize' => ini_get('upload_max_filesize'),
                'post_max_size' => ini_get('post_max_size')
            ];
            
            foreach ($settings as $setting => $value) {
                $checks['config'][$setting] = [
                    'status' => 'info',
                    'message' => $value,
                    'critical' => false
                ];
            }
            
            // Display results
            $sections = [
                'php' => '🔧 PHP Environment',
                'database' => '🗄️ Database',
                'files' => '📁 Files & Permissions', 
                'server' => '🖥️ Server Info',
                'security' => '🔒 Security',
                'config' => '⚙️ PHP Configuration'
            ];
            
            foreach ($sections as $sectionKey => $sectionTitle) {
                if (isset($checks[$sectionKey])) {
                    echo "<div class='check-section'>";
                    echo "<div class='section-header'>{$sectionTitle}</div>";
                    echo "<div class='section-body'>";
                    
                    foreach ($checks[$sectionKey] as $label => $check) {
                        echo "<div class='check-item'>";
                        echo "<div class='check-label'>{$label}</div>";
                        echo "<div class='check-status status-{$check['status']}'>{$check['message']}</div>";
                        echo "</div>";
                    }
                    
                    echo "</div></div>";
                }
            }
            ?>
            
            <!-- Summary -->
            <div class="summary <?= $hasErrors ? 'error' : ($hasWarnings ? 'warning' : 'success') ?>">
                <?php if (!$hasErrors && !$hasWarnings): ?>
                    <h3>✅ Hệ thống hoạt động tốt!</h3>
                    <p>Tất cả yêu cầu đều được đáp ứng. Website sẵn sàng hoạt động.</p>
                <?php elseif ($hasErrors): ?>
                    <h3>❌ Có lỗi cần khắc phục</h3>
                    <p>Một số yêu cầu quan trọng chưa được đáp ứng. Vui lòng kiểm tra và khắc phục.</p>
                <?php else: ?>
                    <h3>⚠️ Hệ thống hoạt động nhưng có cảnh báo</h3>
                    <p>Website có thể hoạt động nhưng một số tính năng có thể bị hạn chế.</p>
                <?php endif; ?>
            </div>
            
            <?php if ($hasErrors): ?>
            <div class="warning-box">
                <h4>🔧 Cách khắc phục lỗi:</h4>
                <ul>
                    <li><strong>Lỗi database:</strong> Kiểm tra thông tin kết nối trong backend/config/database.php</li>
                    <li><strong>File thiếu:</strong> Đảm bảo đã upload đầy đủ files từ package</li>
                    <li><strong>PHP version:</strong> Liên hệ hosting provider để upgrade PHP</li>
                    <li><strong>Extensions thiếu:</strong> Thường có sẵn trên InfinityFree</li>
                </ul>
            </div>
            <?php endif; ?>
            
            <div style="text-align: center; margin-top: 30px;">
                <a href="/" class="btn">🏠 Về trang chủ</a>
                <a href="?check=system" class="btn">🔄 Kiểm tra lại</a>
                <?php if (file_exists('test_connection.php')): ?>
                <a href="test_connection.php" class="btn">🧪 Test Database</a>
                <?php endif; ?>
            </div>
            
            <div class="warning-box" style="margin-top: 30px;">
                <strong>⚠️ BẢO MẬT:</strong> Xóa file này sau khi kiểm tra xong để tránh lộ thông tin hệ thống!
                <div class="code-block">rm system_check.php</div>
            </div>
        </div>
    </div>
</body>
</html>
