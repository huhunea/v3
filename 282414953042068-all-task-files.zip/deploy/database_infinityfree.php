<?php
/**
 * Database Config tối ưu cho InfinityFree
 * Tạo bởi: MiniMax Agent
 * 
 * Hướng dẫn:
 * 1. Thay đổi thông tin database bên dưới
 * 2. Upload file này thay cho backend/config/database.php
 */

// =====================================================
// CẤU HÌNH DATABASE - THAY ĐỔI THÔNG TIN NÀY
// =====================================================

define('DB_HOST', 'sql200.infinityfree.com');        // Thay bằng MySQL host của bạn
define('DB_NAME', 'epiz_xxxxx_khoahoc');             // Thay bằng database name
define('DB_USER', 'epiz_xxxxx_dbuser');              // Thay bằng database username  
define('DB_PASS', 'your_password_here');             // Thay bằng database password
define('DB_CHARSET', 'utf8mb4');

// =====================================================
// KHÔNG THAY ĐỔI PHẦN BÊN DƯỚI
// =====================================================

class Database {
    private $host = DB_HOST;
    private $db_name = DB_NAME;
    private $username = DB_USER;
    private $password = DB_PASS;
    private $charset = DB_CHARSET;
    private $pdo;

    public function connect() {
        if ($this->pdo == null) {
            try {
                $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=" . $this->charset;
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::ATTR_PERSISTENT => false, // Tắt persistent connection cho hosting miễn phí
                ];
                $this->pdo = new PDO($dsn, $this->username, $this->password, $options);
                
                // Set UTF8 encoding
                $this->pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
                
            } catch(PDOException $e) {
                // Ghi log lỗi vào file thay vì hiển thị chi tiết
                error_log("Database Connection Error: " . $e->getMessage());
                
                // Hiển thị thông báo thân thiện cho user
                die("
                <div style='padding:20px;text-align:center;font-family:Arial,sans-serif;'>
                    <h2>🔧 Website đang bảo trì</h2>
                    <p>Chúng tôi đang khắc phục sự cố kết nối database.</p>
                    <p>Vui lòng thử lại sau ít phút.</p>
                    <hr style='margin:20px 0;'>
                    <small>Mã lỗi: DB_CONNECTION_FAILED</small>
                </div>
                ");
            }
        }
        return $this->pdo;
    }
    
    // Test kết nối database
    public function testConnection() {
        try {
            $pdo = $this->connect();
            $stmt = $pdo->query("SELECT 1");
            return ['success' => true, 'message' => 'Kết nối database thành công'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Lỗi kết nối: ' . $e->getMessage()];
        }
    }
    
    // Lấy thông tin database server
    public function getServerInfo() {
        try {
            $pdo = $this->connect();
            $version = $pdo->query("SELECT VERSION()")->fetchColumn();
            $charset = $pdo->query("SHOW VARIABLES LIKE 'character_set_database'")->fetch();
            
            return [
                'version' => $version,
                'charset' => $charset['Value'] ?? 'Unknown',
                'host' => $this->host,
                'database' => $this->db_name
            ];
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }
}

// Auto-test connection nếu được gọi trực tiếp
if (basename($_SERVER['PHP_SELF']) == 'database.php') {
    header('Content-Type: application/json; charset=utf-8');
    
    $db = new Database();
    $test = $db->testConnection();
    
    if ($test['success']) {
        $info = $db->getServerInfo();
        echo json_encode([
            'status' => 'OK',
            'message' => $test['message'],
            'server_info' => $info,
            'timestamp' => date('Y-m-d H:i:s')
        ], JSON_UNESCAPED_UNICODE);
    } else {
        http_response_code(500);
        echo json_encode([
            'status' => 'ERROR',
            'message' => $test['message'],
            'timestamp' => date('Y-m-d H:i:s')
        ], JSON_UNESCAPED_UNICODE);
    }
}
?>
